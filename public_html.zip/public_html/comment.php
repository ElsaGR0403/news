<?php
include('conexion.php');
$nombre=$_POST['name'];
$coment=$_POST['comentario'];
$id_not=$_GET['id'];


$conn = conectarBD();
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO Comentarios(id_not,nombre,comentario) VALUES ($id_not,'$nombre','$coment')";

if (mysqli_query($conn, $sql)) {
     header("Location: single-blog.php");
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
$conn -> close();
?>